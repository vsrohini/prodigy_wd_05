const apiKey = "8383814ffcff4d11b2c154655241611"; // Replace with your WeatherAPI key

// Fetch weather by city name
async function fetchWeather() {
  const location = document.getElementById("locationInput").value;
  if (!location) {
    alert("Please enter a city name.");
    return;
  }

  const url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${location}`;

  try {
    const response = await fetch(url);
    const data = await response.json();
    displayWeather(data);
  } catch (error) {
    console.error("Error fetching weather data:", error);
    alert("Could not retrieve weather data. Please try again.");
  }
}

// Fetch weather using geolocation
async function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;

        const url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${latitude},${longitude}`;

        try {
          const response = await fetch(url);
          const data = await response.json();
          displayWeather(data);
        } catch (error) {
          console.error("Error fetching weather data:", error);
          alert("Could not retrieve weather data. Please try again.");
        }
      },
      (error) => {
        alert(
          "Unable to retrieve location. Please ensure location services are enabled."
        );
        console.error("Geolocation error:", error);
      }
    );
  } else {
    alert("Geolocation is not supported by your browser.");
  }
}

// Display weather data
function displayWeather(data) {
  if (data.error) {
    alert(data.error.message);
    return;
  }

  const weatherResult = document.getElementById("weatherResult");
  weatherResult.innerHTML = `
        <p><strong>Location:</strong> ${data.location.name}, ${data.location.country}</p>
        <p><strong>Temperature:</strong> ${data.current.temp_c}°C</p>
        <p><strong>Condition:</strong> ${data.current.condition.text}</p>
        <p><strong>Humidity:</strong> ${data.current.humidity}%</p>
        <p><strong>Wind Speed:</strong> ${data.current.wind_kph} kph</p>
    `;
}
